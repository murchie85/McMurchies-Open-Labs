import jobone as jb  


print("running tests")
jb 

print("tests complete")