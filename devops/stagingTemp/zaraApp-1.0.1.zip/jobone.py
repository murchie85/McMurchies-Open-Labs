import time as time 

print("Staring Applicaiton") 
 
time.sleep(2)  

print("Jobs complete")